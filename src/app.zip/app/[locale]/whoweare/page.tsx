import React from 'react'

const page = () => {
  return (
    <div className="min-h-screen flex flex-col justify-center ">
        <h1 className='text-center uppercase text-6xl text-amber-500'>Who we are?</h1>
        </div>
  )
}

export default page