import React from 'react'

const page = () => {
  return (
    <div className="flex flex-col items-center">
<h1 className="text-3xl font-black uppercase text-orange-500">What We Do</h1>

    </div>
  )
}

export default page